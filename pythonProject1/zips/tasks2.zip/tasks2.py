
# 1st task
example = "Communicate"
lenExample = len(example)
halfLenExample = int(-1 * lenExample / 2)-1
# 2nd task
print(example[0])
# 3rd task
print(example[-1])
# 4th task
print(example[halfLenExample:])
# 5th task
print(example[::-1])
# 6th task
print(example[1:lenExample:2])

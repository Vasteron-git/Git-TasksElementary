# 1st program комментарий
print('1th program:')
print( 9 ** 0.5 )
print( 9 ** 0.5 * 5 )

# 2nd program
print('2th program:')
print(9.99 > 9.99)

# 3rd program Школьная загадка
print('3th program:')
print( 2 * 2 + 2 )
print( 2 * (2 + 2) )
print( (2 * 2 + 2)  ==  (2 * (2 + 2)))

# 4th program
print('4th program:')
print(int(123.456 * 10 % 10))
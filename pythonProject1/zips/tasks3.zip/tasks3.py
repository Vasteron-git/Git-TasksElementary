
# 1st task
number_of_HW = 12
# 2nd task
number_of_hours_spent = 1.5
# 3rd task
name_of_course = "Python"
# 4th task
time_for_one_task = number_of_hours_spent / number_of_HW
print("Курс: ",name_of_course, ", всего задач:", number_of_HW, ", затрачено часов: ",
      number_of_hours_spent, ", среднее время выполнения ",time_for_one_task,"часа.")

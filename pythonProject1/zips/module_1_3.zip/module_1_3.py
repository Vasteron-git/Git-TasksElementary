from operator import truediv

name = "Максим"
print("Name: " + name)
age  = 48
print("Age:", age)
age = age + 5
print("New фge:", age)
is_student =  'true'
print("is_student: " + is_student)

